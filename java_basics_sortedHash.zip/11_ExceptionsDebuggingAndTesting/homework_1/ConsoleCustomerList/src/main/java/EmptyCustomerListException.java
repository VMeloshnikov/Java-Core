public class EmptyCustomerListException extends  Exception{
    public EmptyCustomerListException(String message) {
        super(message);
    }
}