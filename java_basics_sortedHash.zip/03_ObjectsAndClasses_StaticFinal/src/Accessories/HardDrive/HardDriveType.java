package Accessories.HardDrive;

public enum HardDriveType {
    SSD, HDD
}
