package Accessories.Monitor;

public enum MonitorType {
    IPS, TN, VA
}
