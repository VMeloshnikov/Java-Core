package Accessories.Keyboard;

public enum KeyboardBackLight {
    YES, NO
}
