package Accessories.Keyboard;

public enum KeyboardType {
    USB, BLUETOOTH, RADIO
}
