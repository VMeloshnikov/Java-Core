package Accessories.Memory;

public enum MemoryType {
    DDR, DDR_II, DDR_III, DDR_IV
}
