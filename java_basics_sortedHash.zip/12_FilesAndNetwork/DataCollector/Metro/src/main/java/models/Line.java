package models;

import lombok.Data;

@Data
public class Line {
    private String name;
    private String number;
}
