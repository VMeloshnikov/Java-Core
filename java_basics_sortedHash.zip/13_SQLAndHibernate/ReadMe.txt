Работа с MySQL в Java
Пройдено: Подключение через JDBC, запросы ResultSet, Hubernate, связи ManyToOne и OneToMany, ManyToMany.
Hibernate query builer, HQL.

В заданиях практика по: подключению MySQL в проекте;
			Написание SQL-запросов к базе данных в коде.
			Подключение к проекту библиотеки Hibernate;
			Создание классов @Entity со связями;
			Создание таблицы в базе данных при помощи Hibernate и заполнение их данными.