package practice;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;

public class DepositAccount extends BankAccount {
    LocalDate lastIncome = LocalDate.now();
    @Override
    public void put(double amountToPut) {
        super.put(amountToPut);
        lastIncome = LocalDate.now();
    }
    @Override
    public void take(double amountToTake) {
        Period period = Period.between(lastIncome, LocalDate.now());
        if (period.getMonths() >= 1 || period.getYears() >= 1) {
            super.take(amountToTake);
        }
        System.out.println(amountToTake);
    }

}

