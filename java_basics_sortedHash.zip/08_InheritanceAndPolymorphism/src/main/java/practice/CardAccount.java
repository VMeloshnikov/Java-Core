package practice;

public class CardAccount extends BankAccount {
    @Override
    public void take(double amount) {
        super.take(amount * 1.01);
    }
}

