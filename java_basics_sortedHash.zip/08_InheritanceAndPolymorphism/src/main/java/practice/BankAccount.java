package practice;

import java.time.LocalDate;
import java.time.Period;

public class BankAccount {
    double amount;

    public double getAmount() {

        return amount;
    }

     public void put(double amountToPut) {
        if (amountToPut < 0) {
            System.out.println("Неверная операция");
        } else {
            amount = amount + amountToPut;
            System.out.println("Баланс пополнен на:" + amountToPut);
        }

    }

    public void take(double amountToTake) {
        if (amountToTake > amount) {
            System.out.println("Попытка снятия больше доступного");
        } else {
            amount = amount - amountToTake;
            System.out.println("Баланс: " + amount);
        }
    }
}






